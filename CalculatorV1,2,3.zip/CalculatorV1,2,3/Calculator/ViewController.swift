//
//  ViewController.swift
//  Calculator
//
//  Created by Sergey A. Kutylev on 01.02.17.
//  Copyright © 2017 Amin Nazari. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var display: UILabel!
    var usertyping = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnpressed(_ sender: UIButton) {
        let diget = sender.currentTitle!
        if usertyping {
            let textCurrentDisply = display.text!
            display.text = textCurrentDisply + diget
        }else{
            display.text = diget
        }
        usertyping = true
    }
    
    var displayValue: Double{
        get {
            return Double(display.text!)!
        }
        set {
            display.text = String(newValue)
        }
        
    }
    fileprivate var brain = Calculator()
    @IBAction func preformOperation(_ sender: UIButton) {
        if usertyping{
            brain.setOpreand(displayValue)
            usertyping = false
        }
        usertyping = false
        if let methematicalSymbole = sender.currentTitle{
            brain.preformOperations(methematicalSymbole)
        }
        displayValue = brain.result
    }

}

