//
//  File.swift
//  Calculator
//
//  Created by Sergey A. Kutylev on 07.02.17.
//  Copyright © 2017 Amin Nazari. All rights reserved.
//

import Foundation

class Calculator {
    var accumlator = 0.0
    
    func setOpreand(_ operand:Double){
        accumlator = operand
    }
    
    var operations : Dictionary<String, Operation> = [
        "∏" : Operation.constant(M_PI),
        "e" : Operation.constant(M_E),
        "√" : Operation.unaryOperation(sqrt),
        "cos": Operation.unaryOperation(cos),
        "±" : Operation.unaryOperation({ -$0 }),
        "×" : Operation.binaryOperation({$0 * $1}),
        "÷" : Operation.binaryOperation({$0 / $1}),
        "+" : Operation.binaryOperation({$0 + $1}),
        "−" : Operation.binaryOperation({$0 - $1}),
        "=" : Operation.equals
    ]
    
    enum Operation {
        case constant(Double)
        case unaryOperation ((Double) -> Double)
        case binaryOperation((Double, Double) -> Double)
        case equals
    }
    
    func preformOperations(_ symbole: String){
       if let operation = operations[symbole]{
        switch operation{
            case .constant(let value):
                accumlator = value
            case .unaryOperation(let function):
                accumlator = function(accumlator)
            case .binaryOperation(let function):
                excuteBinaryPinding()
                pending = PendingBinaryOperation(birnaryFunction: function, firstOperation: accumlator)
        case .equals:
            excuteBinaryPinding()
        }
      }
    }
    
   func excuteBinaryPinding()
    {
        if pending != nil {
            accumlator = pending!.birnaryFunction(pending!.firstOperation, accumlator)
            pending = nil
        }
    
    }
    
    var pending : PendingBinaryOperation?
    
    struct PendingBinaryOperation {
        var birnaryFunction: ((Double, Double) ->Double)
        var firstOperation: Double
    }
    
    var result: Double{
        return accumlator
        
    }
}
